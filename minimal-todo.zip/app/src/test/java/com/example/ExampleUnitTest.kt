package com.example

import com.example.data.model.TodoEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun `filter todo items by title or content`() {
    val todos = listOf(
      TodoEntity(id = 1, title = "Clean espresso machine", content = "Backflush group heads with cleaning powder"),
      TodoEntity(id = 2, title = "Check milk inventory", content = "Inspect expiration dates on oat milk and dairy cartons"),
      TodoEntity(id = 3, title = "Bake fresh croissants", content = "Warm up oven to 180 degrees and bake morning pastries"),
      TodoEntity(id = 4, title = "Yuzu syrup prep", content = "Squeeze fresh oranges and prepare syrup for Americano")
    )

    // Filter by title
    val titleResults = todos.filter {
      it.title.contains("espresso", ignoreCase = true) || it.content.contains("espresso", ignoreCase = true)
    }
    assertEquals(1, titleResults.size)
    assertEquals("Clean espresso machine", titleResults[0].title)

    // Filter by content
    val contentResults = todos.filter {
      it.title.contains("expiration", ignoreCase = true) || it.content.contains("expiration", ignoreCase = true)
    }
    assertEquals(1, contentResults.size)
    assertEquals("Check milk inventory", contentResults[0].title)

    // Filter case-insensitive match on both title or content
    val generalResults = todos.filter {
      it.title.contains("OAT", ignoreCase = true) || it.content.contains("OAT", ignoreCase = true)
    }
    assertEquals(1, generalResults.size)
    assertEquals(2L, generalResults[0].id)

    // Empty query returns all
    val emptyQuery = ""
    val allResults = if (emptyQuery.isBlank()) todos else todos.filter {
      it.title.contains(emptyQuery, ignoreCase = true) || it.content.contains(emptyQuery, ignoreCase = true)
    }
    assertEquals(4, allResults.size)
  }

  @Test
  fun `todo items priority levels and filtering`() {
    val items = listOf(
      com.example.data.model.TodoEntity(id = 1, title = "Task 1", content = "Details", priority = "HIGH"),
      com.example.data.model.TodoEntity(id = 2, title = "Task 2", content = "Details", priority = "MEDIUM"),
      com.example.data.model.TodoEntity(id = 3, title = "Task 3", content = "Details", priority = "LOW"),
      com.example.data.model.TodoEntity(id = 4, title = "Task 4", content = "Details") // default is MEDIUM
    )

    assertEquals(com.example.data.model.TodoPriority.HIGH, items[0].priorityLevel)
    assertEquals(com.example.data.model.TodoPriority.MEDIUM, items[1].priorityLevel)
    assertEquals(com.example.data.model.TodoPriority.LOW, items[2].priorityLevel)
    assertEquals(com.example.data.model.TodoPriority.MEDIUM, items[3].priorityLevel)

    // Filter by HIGH priority
    val highItems = items.filter { it.priorityLevel == com.example.data.model.TodoPriority.HIGH }
    assertEquals(1, highItems.size)
    assertEquals(1L, highItems[0].id)

    // Filter by MEDIUM priority
    val mediumItems = items.filter { it.priorityLevel == com.example.data.model.TodoPriority.MEDIUM }
    assertEquals(2, mediumItems.size)

    // Filter by LOW priority
    val lowItems = items.filter { it.priorityLevel == com.example.data.model.TodoPriority.LOW }
    assertEquals(1, lowItems.size)
    assertEquals(3L, lowItems[0].id)

    // Test unknown priority fallback to MEDIUM
    val fallbackItem = com.example.data.model.TodoEntity(id = 5, title = "Task 5", content = "Details", priority = "UNKNOWN")
    assertEquals(com.example.data.model.TodoPriority.MEDIUM, fallbackItem.priorityLevel)
  }
}

