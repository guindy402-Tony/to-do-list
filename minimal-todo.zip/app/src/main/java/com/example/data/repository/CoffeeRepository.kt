package com.example.data.repository

import com.example.data.local.CoffeeDao
import com.example.data.model.FavoriteEntity
import com.example.data.model.OrderEntity
import com.example.data.model.RewardEntity
import com.example.data.model.TodoEntity
import com.example.data.model.TodoPriority
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class CoffeeRepository(private val coffeeDao: CoffeeDao) {

    val orders: Flow<List<OrderEntity>> = coffeeDao.getAllOrders()
    val favorites: Flow<List<FavoriteEntity>> = coffeeDao.getAllFavorites()
    val reward: Flow<RewardEntity?> = coffeeDao.getReward()
    val todos: Flow<List<TodoEntity>> = coffeeDao.getAllTodos()

    suspend fun placeOrder(order: OrderEntity): Long {
        val id = coffeeDao.insertOrder(order)
        // Automatically award stamps (1 stamp per order)
        val currentReward = coffeeDao.getReward().firstOrNull() ?: RewardEntity(id = 1, stampCount = 3, freeDrinksClaimed = 0)
        val newStamps = currentReward.stampCount + 1
        coffeeDao.saveReward(currentReward.copy(stampCount = newStamps))
        return id
    }

    suspend fun updateOrderStatus(orderId: Long, newStatus: String) {
        coffeeDao.updateOrderStatus(orderId, newStatus)
    }

    suspend fun toggleFavorite(coffeeId: String, isCurrentlyFav: Boolean) {
        if (isCurrentlyFav) {
            coffeeDao.deleteFavorite(coffeeId)
        } else {
            coffeeDao.insertFavorite(FavoriteEntity(coffeeId = coffeeId))
        }
    }

    suspend fun redeemStamp() {
        val currentReward = coffeeDao.getReward().firstOrNull() ?: RewardEntity(id = 1, stampCount = 10, freeDrinksClaimed = 0)
        if (currentReward.stampCount >= 10) {
            coffeeDao.saveReward(
                currentReward.copy(
                    stampCount = currentReward.stampCount - 10,
                    freeDrinksClaimed = currentReward.freeDrinksClaimed + 1
                )
            )
        }
    }

    suspend fun addTodo(
        title: String,
        content: String,
        priority: TodoPriority = TodoPriority.MEDIUM
    ): Long {
        return coffeeDao.insertTodo(
            TodoEntity(
                title = title,
                content = content,
                priority = priority.name
            )
        )
    }

    suspend fun updateTodoPriority(todo: TodoEntity, newPriority: TodoPriority) {
        coffeeDao.updateTodo(todo.copy(priority = newPriority.name))
    }

    suspend fun toggleTodo(todo: TodoEntity) {
        coffeeDao.updateTodo(todo.copy(isCompleted = !todo.isCompleted))
    }

    suspend fun deleteTodo(id: Long) {
        coffeeDao.deleteTodo(id)
    }
}

