package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class CoffeeCategory(
    val titleTh: String,
    val titleEn: String,
    val emoji: String
) {
    ALL("ทั้งหมด", "All", "✨"),
    COFFEE("กาแฟสด", "Coffee", "☕"),
    TEA_MILK("ชา & นมสด", "Tea & Milk", "🍵"),
    REFRESHER("โซดา & สดชื่น", "Refreshers", "🥤"),
    BAKERY("เบเกอรี่", "Bakery", "🥐")
}

enum class DrinkType(val titleTh: String, val extraPrice: Double) {
    HOT("ร้อน", 0.0),
    ICED("เย็น", 5.0),
    FRAPPE("ปั่น", 10.0)
}

enum class SweetnessLevel(val titleTh: String, val percentage: String) {
    ZERO("ไม่หวาน", "0%"),
    LESS("หวานน้อย", "25%"),
    BALANCED("หวานพอดี (แนะนำ)", "50%"),
    NORMAL("หวานปกติ", "100%"),
    SWEET("หวานฉ่ำ", "125%")
}

enum class RoastLevel(val titleTh: String, val descTh: String) {
    DARK("คั่วเข้ม", "เข้มข้น หอมกลิ่นคั่ว เหมาะดื่มเติมนม"),
    MEDIUM("คั่วกลาง", "รสชาติกลมกล่อม หอมถั่วและช็อกโกแลต"),
    LIGHT("คั่วอ่อน", "บอดี้เบา เปรี้ยวผลไม้ฟรุตตี้สดชื่น")
}

data class DrinkTopping(
    val id: String,
    val nameTh: String,
    val extraPrice: Double
)

data class CoffeeItem(
    val id: String,
    val nameTh: String,
    val nameEn: String,
    val description: String,
    val category: CoffeeCategory,
    val basePrice: Double,
    val rating: Double = 4.8,
    val reviewCount: Int = 95,
    val isBestSeller: Boolean = false,
    val isSignature: Boolean = false,
    val availableTypes: List<DrinkType> = listOf(DrinkType.HOT, DrinkType.ICED, DrinkType.FRAPPE),
    val supportsRoastLevel: Boolean = true,
    val badgeTag: String? = null,
    val imageResName: String = "coffee_cup",
    val imageUrl: String = ""
)

data class CartItem(
    val cartItemId: String,
    val coffeeItem: CoffeeItem,
    val selectedType: DrinkType,
    val sweetness: SweetnessLevel,
    val roastLevel: RoastLevel?,
    val selectedToppings: List<DrinkTopping> = emptyList(),
    val noteToBarista: String = "",
    val quantity: Int = 1
) {
    val unitPrice: Double
        get() = coffeeItem.basePrice + selectedType.extraPrice + selectedToppings.sumOf { it.extraPrice }

    val totalPrice: Double
        get() = unitPrice * quantity
}

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val orderNumber: String,
    val queueNumber: String,
    val itemsSummary: String,
    val totalAmount: Double,
    val discountAmount: Double,
    val netAmount: Double,
    val orderType: String, // "รับที่ร้าน", "ทานที่ร้าน", "เดลิเวอรี่"
    val tableOrAddress: String,
    val paymentMethod: String, // "สแกน QR พร้อมเพย์", "เงินสดหน้าร้าน", "บัตรเครดิต"
    val status: String, // "กำลังชงเครื่องดื่ม", "พร้อมรับสินค้า", "เสร็จสิ้น"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey
    val coffeeId: String,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "rewards")
data class RewardEntity(
    @PrimaryKey
    val id: Int = 1,
    val stampCount: Int = 3, // Initial bonus stamps for demo
    val freeDrinksClaimed: Int = 0
)

enum class TodoPriority(
    val titleTh: String,
    val titleEn: String,
    val colorHex: Long,
    val bgHex: Long
) {
    LOW("ความสำคัญต่ำ (Low)", "Low", 0xFF2E7D32, 0xFFE8F5E9),       // Green
    MEDIUM("ปานกลาง (Medium)", "Medium", 0xFFEF6C00, 0xFFFFF3E0),    // Orange
    HIGH("ด่วน / สำคัญมาก (High)", "High", 0xFFC62828, 0xFFFFEBEE)   // Red
}

@Entity(tableName = "todo_items")
data class TodoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val isCompleted: Boolean = false,
    val priority: String = "MEDIUM",
    val createdAt: Long = System.currentTimeMillis()
) {
    val priorityLevel: TodoPriority
        get() = try {
            TodoPriority.valueOf(priority)
        } catch (_: Exception) {
            TodoPriority.MEDIUM
        }
}

