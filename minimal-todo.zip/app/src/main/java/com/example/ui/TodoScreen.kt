package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.MinimalAddEditSheet
import com.example.ui.components.MinimalEmptyState
import com.example.ui.components.MinimalFilterTabs
import com.example.ui.components.MinimalHeader
import com.example.ui.components.MinimalQuickAddBar
import com.example.ui.components.MinimalTodoItemCard
import com.example.ui.components.SwipeableTodoItem
import com.example.ui.theme.PureWhite

@Composable
fun TodoScreen(
    viewModel: TodoViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("todo_screen"),
        containerColor = PureWhite,
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            ) {
                MinimalQuickAddBar(
                    onQuickAdd = { title ->
                        viewModel.addTodo(
                            title = title,
                            category = if (state.selectedCategory != "ทั้งหมด") state.selectedCategory else "ทั่วไป"
                        )
                    },
                    onOpenFullAdd = {
                        viewModel.setAddSheetOpen(true)
                    }
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = innerPadding.calculateTopPadding())
                .background(PureWhite)
        ) {
            // Header: Date, App Title, Actions, Progress bar
            MinimalHeader(
                totalCount = state.totalCount,
                completedCount = state.completedCount,
                completionPercentage = state.completionPercentage,
                isSearchOpen = state.isSearchOpen,
                searchQuery = state.searchQuery,
                onSearchQueryChange = { viewModel.setSearchQuery(it) },
                onToggleSearch = { viewModel.toggleSearch() },
                onClearCompleted = { viewModel.clearCompleted() }
            )

            // Status Filter Tabs & Category Chips
            MinimalFilterTabs(
                currentFilter = state.currentFilter,
                onFilterSelect = { viewModel.setFilter(it) },
                selectedCategory = state.selectedCategory,
                availableCategories = state.availableCategories,
                onCategorySelect = { viewModel.setCategory(it) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Todo Items List
            if (state.items.isEmpty()) {
                MinimalEmptyState(currentFilter = state.currentFilter)
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("todo_list"),
                    contentPadding = PaddingValues(
                        start = 20.dp,
                        end = 20.dp,
                        top = 8.dp,
                        bottom = innerPadding.calculateBottomPadding() + 80.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(
                        items = state.items,
                        key = { it.id }
                    ) { item ->
                        SwipeableTodoItem(
                            item = item,
                            onToggle = { viewModel.toggleTodo(item) },
                            onEdit = { viewModel.setEditingItem(item) },
                            onDelete = { viewModel.deleteTodo(item) }
                        )
                    }
                }
            }
        }
    }

    // Add New Task Sheet
    if (state.isAddSheetOpen) {
        MinimalAddEditSheet(
            initialItem = null,
            categories = state.availableCategories,
            onDismiss = { viewModel.setAddSheetOpen(false) },
            onSave = { title, note, category, priority ->
                viewModel.addTodo(
                    title = title,
                    note = note,
                    category = category,
                    priority = priority
                )
                viewModel.setAddSheetOpen(false)
            }
        )
    }

    // Edit Existing Task Sheet
    state.editingItem?.let { itemToEdit ->
        MinimalAddEditSheet(
            initialItem = itemToEdit,
            categories = state.availableCategories,
            onDismiss = { viewModel.setEditingItem(null) },
            onSave = { title, note, category, priority ->
                viewModel.updateTodo(
                    itemToEdit.copy(
                        title = title,
                        note = note,
                        category = category,
                        priority = priority
                    )
                )
                viewModel.setEditingItem(null)
            }
        )
    }
}
