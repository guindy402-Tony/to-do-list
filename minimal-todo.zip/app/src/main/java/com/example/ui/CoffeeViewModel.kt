package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.CoffeeMenuData
import com.example.data.model.CartItem
import com.example.data.model.CoffeeCategory
import com.example.data.model.CoffeeItem
import com.example.data.model.DrinkTopping
import com.example.data.model.DrinkType
import com.example.data.model.OrderEntity
import com.example.data.model.RewardEntity
import com.example.data.model.RoastLevel
import com.example.data.model.SweetnessLevel
import com.example.data.model.TodoEntity
import com.example.data.model.TodoPriority
import com.example.data.repository.CoffeeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class CoffeeViewModel(private val repository: CoffeeRepository) : ViewModel() {

    // Menu & Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow(CoffeeCategory.ALL)
    val selectedCategory: StateFlow<CoffeeCategory> = _selectedCategory.asStateFlow()

    // Filtered Menu Items
    val filteredMenuItems: StateFlow<List<CoffeeItem>> = combine(
        _searchQuery,
        _selectedCategory
    ) { query, category ->
        CoffeeMenuData.menuItems.filter { item ->
            val matchesCategory = category == CoffeeCategory.ALL || item.category == category
            val matchesQuery = query.isBlank() ||
                    item.nameTh.contains(query, ignoreCase = true) ||
                    item.nameEn.contains(query, ignoreCase = true) ||
                    item.description.contains(query, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CoffeeMenuData.menuItems)

    // Best Sellers & Recommended
    val bestSellerItems: List<CoffeeItem> = CoffeeMenuData.menuItems.filter { it.isBestSeller }

    // Cart
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    // Promo Code
    private val _appliedPromoCode = MutableStateFlow<String?>(null)
    val appliedPromoCode: StateFlow<String?> = _appliedPromoCode.asStateFlow()

    private val _promoDiscountPercent = MutableStateFlow(0)
    val promoDiscountPercent: StateFlow<Int> = _promoDiscountPercent.asStateFlow()

    // Order Type & Payment
    private val _orderType = MutableStateFlow("รับที่ร้าน") // "รับที่ร้าน", "ทานที่ร้าน (ระบุโต๊ะ)", "เดลิเวอรี่ริมทาง"
    val orderType: StateFlow<String> = _orderType.asStateFlow()

    private val _tableOrAddress = MutableStateFlow("")
    val tableOrAddress: StateFlow<String> = _tableOrAddress.asStateFlow()

    private val _paymentMethod = MutableStateFlow("สแกน QR พร้อมเพย์")
    val paymentMethod: StateFlow<String> = _paymentMethod.asStateFlow()

    // Active Customization Dialog
    private val _customizingItem = MutableStateFlow<CoffeeItem?>(null)
    val customizingItem: StateFlow<CoffeeItem?> = _customizingItem.asStateFlow()

    // Placed Order feedback
    private val _lastPlacedOrder = MutableStateFlow<OrderEntity?>(null)
    val lastPlacedOrder: StateFlow<OrderEntity?> = _lastPlacedOrder.asStateFlow()

    private val _showOrderSuccessDialog = MutableStateFlow(false)
    val showOrderSuccessDialog: StateFlow<Boolean> = _showOrderSuccessDialog.asStateFlow()

    // Database Flows
    val orderHistory: StateFlow<List<OrderEntity>> = repository.orders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteIds: StateFlow<Set<String>> = repository.favorites
        .combine(MutableStateFlow(Unit)) { favs, _ ->
            favs.map { it.coffeeId }.toSet()
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    val rewardInfo: StateFlow<RewardEntity> = repository.reward
        .combine(MutableStateFlow(Unit)) { reward, _ ->
            reward ?: RewardEntity(id = 1, stampCount = 3, freeDrinksClaimed = 0)
        }.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            RewardEntity(id = 1, stampCount = 3, freeDrinksClaimed = 0)
        )

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: CoffeeCategory) {
        _selectedCategory.value = category
    }

    fun openCustomization(item: CoffeeItem) {
        _customizingItem.value = item
    }

    fun closeCustomization() {
        _customizingItem.value = null
    }

    fun addToCart(
        coffeeItem: CoffeeItem,
        selectedType: DrinkType,
        sweetness: SweetnessLevel,
        roastLevel: RoastLevel?,
        selectedToppings: List<DrinkTopping>,
        noteToBarista: String,
        quantity: Int
    ) {
        val newItem = CartItem(
            cartItemId = UUID.randomUUID().toString(),
            coffeeItem = coffeeItem,
            selectedType = selectedType,
            sweetness = sweetness,
            roastLevel = roastLevel,
            selectedToppings = selectedToppings,
            noteToBarista = noteToBarista,
            quantity = quantity
        )
        _cartItems.value = _cartItems.value + newItem
        _customizingItem.value = null
    }

    fun updateCartQuantity(cartItemId: String, delta: Int) {
        _cartItems.value = _cartItems.value.mapNotNull { item ->
            if (item.cartItemId == cartItemId) {
                val newQty = item.quantity + delta
                if (newQty > 0) item.copy(quantity = newQty) else null
            } else {
                item
            }
        }
    }

    fun removeCartItem(cartItemId: String) {
        _cartItems.value = _cartItems.value.filter { it.cartItemId != cartItemId }
    }

    fun clearCart() {
        _cartItems.value = emptyList()
        _appliedPromoCode.value = null
        _promoDiscountPercent.value = 0
    }

    fun applyPromoCode(code: String): String {
        val trimmed = code.trim().uppercase()
        return when (trimmed) {
            "RIMTHANG10" -> {
                _appliedPromoCode.value = "RIMTHANG10"
                _promoDiscountPercent.value = 10
                "ใช้โค้ดสำเร็จ! ลด 10%"
            }
            "NEWBIE" -> {
                _appliedPromoCode.value = "NEWBIE"
                _promoDiscountPercent.value = 15
                "ใช้โค้ดสำเร็จ! ลูกค้าใหม่ลด 15%"
            }
            "COFFEE20" -> {
                _appliedPromoCode.value = "COFFEE20"
                _promoDiscountPercent.value = 20
                "ใช้โค้ดส่วนลด 20% สำเร็จ!"
            }
            else -> {
                "โค้ดไม่ถูกต้อง หรือหมดอายุแล้ว"
            }
        }
    }

    fun removePromoCode() {
        _appliedPromoCode.value = null
        _promoDiscountPercent.value = 0
    }

    fun setOrderType(type: String) {
        _orderType.value = type
    }

    fun setTableOrAddress(note: String) {
        _tableOrAddress.value = note
    }

    fun setPaymentMethod(method: String) {
        _paymentMethod.value = method
    }

    fun toggleFavorite(coffeeId: String) {
        viewModelScope.launch {
            val isFav = favoriteIds.value.contains(coffeeId)
            repository.toggleFavorite(coffeeId, isFav)
        }
    }

    fun placeOrder() {
        val items = _cartItems.value
        if (items.isEmpty()) return

        val subtotal = items.sumOf { it.totalPrice }
        val discountAmount = if (_promoDiscountPercent.value > 0) {
            subtotal * (_promoDiscountPercent.value / 100.0)
        } else 0.0
        val netAmount = (subtotal - discountAmount).coerceAtLeast(0.0)

        // Queue number generator e.g. A-12
        val queueChar = listOf("A", "B", "C").random()
        val queueNum = (10..99).random()
        val queueStr = "คิว $queueChar-$queueNum"

        val orderNum = "RT-" + SimpleDateFormat("ddHHmmss", Locale.getDefault()).format(Date())

        val summary = items.joinToString("\n") {
            val typeStr = it.selectedType.titleTh
            val sweetStr = it.sweetness.percentage
            val toppingsStr = if (it.selectedToppings.isNotEmpty()) " + " + it.selectedToppings.joinToString { t -> t.nameTh.substringBefore(" (") } else ""
            "• ${it.coffeeItem.nameTh} ($typeStr, หวาน $sweetStr$toppingsStr) x${it.quantity} = ฿${String.format(Locale.US, "%.0f", it.totalPrice)}"
        }

        val orderEntity = OrderEntity(
            orderNumber = orderNum,
            queueNumber = queueStr,
            itemsSummary = summary,
            totalAmount = subtotal,
            discountAmount = discountAmount,
            netAmount = netAmount,
            orderType = _orderType.value,
            tableOrAddress = _tableOrAddress.value,
            paymentMethod = _paymentMethod.value,
            status = "กำลังชงเครื่องดื่ม",
            timestamp = System.currentTimeMillis()
        )

        viewModelScope.launch {
            val id = repository.placeOrder(orderEntity)
            _lastPlacedOrder.value = orderEntity.copy(id = id)
            _showOrderSuccessDialog.value = true
            clearCart()
        }
    }

    fun dismissOrderSuccessDialog() {
        _showOrderSuccessDialog.value = false
    }

    fun advanceOrderStatus(orderId: Long, currentStatus: String) {
        viewModelScope.launch {
            val nextStatus = when (currentStatus) {
                "กำลังเตรียมออเดอร์" -> "กำลังชงเครื่องดื่ม"
                "กำลังชงเครื่องดื่ม" -> "พร้อมรับสินค้า ☕"
                "พร้อมรับสินค้า ☕" -> "รับสินค้าเรียบร้อย 🎉"
                else -> "รับสินค้าเรียบร้อย 🎉"
            }
            repository.updateOrderStatus(orderId, nextStatus)
        }
    }

    fun redeemReward() {
        viewModelScope.launch {
            repository.redeemStamp()
        }
    }

    fun reorder(order: OrderEntity) {
        // Quick 1-tap reorder: find matching menu items from summary or prompt user
        val firstItem = CoffeeMenuData.menuItems.firstOrNull { order.itemsSummary.contains(it.nameTh) }
            ?: CoffeeMenuData.menuItems.first()
        addToCart(
            coffeeItem = firstItem,
            selectedType = DrinkType.ICED,
            sweetness = SweetnessLevel.BALANCED,
            roastLevel = RoastLevel.MEDIUM,
            selectedToppings = emptyList(),
            noteToBarista = "สั่งซ้ำจากประวัติ ${order.queueNumber}",
            quantity = 1
        )
    }

    // Todo Items, Priority Filter & Real-time Search Filter by Title or Content
    private val _todoSearchQuery = MutableStateFlow("")
    val todoSearchQuery: StateFlow<String> = _todoSearchQuery.asStateFlow()

    private val _selectedTodoPriorityFilter = MutableStateFlow<TodoPriority?>(null)
    val selectedTodoPriorityFilter: StateFlow<TodoPriority?> = _selectedTodoPriorityFilter.asStateFlow()

    val allTodos: StateFlow<List<TodoEntity>> = repository.todos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredTodos: StateFlow<List<TodoEntity>> = combine(
        repository.todos,
        _todoSearchQuery,
        _selectedTodoPriorityFilter
    ) { todos, query, priorityFilter ->
        todos.filter { todo ->
            val matchesQuery = if (query.isBlank()) {
                true
            } else {
                todo.title.contains(query, ignoreCase = true) ||
                todo.content.contains(query, ignoreCase = true)
            }
            val matchesPriority = priorityFilter == null || todo.priorityLevel == priorityFilter
            matchesQuery && matchesPriority
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        seedInitialTodosIfNeeded()
    }

    private fun seedInitialTodosIfNeeded() {
        viewModelScope.launch {
            val existing = repository.todos.firstOrNull()
            if (existing.isNullOrEmpty()) {
                repository.addTodo(
                    title = "เตรียมเมล็ดกาแฟคั่วเข้มและคั่วกลาง",
                    content = "เช็คสต็อกเมล็ดกาแฟซิกเนเจอร์ริมทาง เติมใส่โถบดให้พร้อมเปิดร้าน 06:30",
                    priority = TodoPriority.HIGH
                )
                repository.addTodo(
                    title = "ทำความสะอาดหัวชงเอสเพรสโซ่",
                    content = "ล้าง backflush เครื่องชงเอสเพรสโซ่และทำความสะอาดก้านชงด้วยผงทำความสะอาด",
                    priority = TodoPriority.HIGH
                )
                repository.addTodo(
                    title = "อบครัวซองต์เนยสดรอบเช้า",
                    content = "วอร์มเตาอบที่ 180 องศา อบขนมเบเกอรี่สดใหม่สำหรับเสิร์ฟคู่กาแฟ",
                    priority = TodoPriority.MEDIUM
                )
                repository.addTodo(
                    title = "เช็คสต็อกนมสดและนมโอ๊ต",
                    content = "ตรวจดูวันหมดอายุและเตรียมสต็อกนมสดฮอกไกโดและ Oat Milk ในตู้เย็น",
                    priority = TodoPriority.MEDIUM
                )
                repository.addTodo(
                    title = "เตรียมน้ำส้มยูซุและน้ำผึ้งป่า",
                    content = "คั้นน้ำส้มสดและเตรียมวัตถุดิบสำหรับเมนูอเมริกาโน่ส้มยูซุและยูซุโซดา",
                    priority = TodoPriority.LOW
                )
            }
        }
    }

    fun setTodoSearchQuery(query: String) {
        _todoSearchQuery.value = query
    }

    fun setTodoPriorityFilter(priority: TodoPriority?) {
        _selectedTodoPriorityFilter.value = priority
    }

    fun addTodo(title: String, content: String, priority: TodoPriority = TodoPriority.MEDIUM) {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.addTodo(title.trim(), content.trim(), priority)
        }
    }

    fun updateTodoPriority(todo: TodoEntity, newPriority: TodoPriority) {
        viewModelScope.launch {
            repository.updateTodoPriority(todo, newPriority)
        }
    }

    fun toggleTodo(todo: TodoEntity) {
        viewModelScope.launch {
            repository.toggleTodo(todo)
        }
    }

    fun deleteTodo(id: Long) {
        viewModelScope.launch {
            repository.deleteTodo(id)
        }
    }
}

class CoffeeViewModelFactory(private val repository: CoffeeRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CoffeeViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return CoffeeViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
