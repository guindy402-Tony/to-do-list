package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Coffee
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.Coffee
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.CustomizationSheet
import com.example.ui.components.OrderSuccessDialog
import com.example.ui.screens.CartScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OrdersScreen
import com.example.ui.screens.RewardsScreen
import com.example.ui.screens.ShopInfoScreen
import com.example.ui.screens.TodoScreen
import com.example.ui.theme.CoffeePrimary
import com.example.ui.theme.CremaGold

enum class RimthangTab(
    val titleTh: String,
    val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val testTag: String
) {
    HOME("เมนู", Icons.Filled.Coffee, Icons.Outlined.Coffee, "nav_tab_home"),
    CART("ตะกร้า", Icons.Filled.ShoppingCart, Icons.Outlined.ShoppingCart, "nav_tab_cart"),
    ORDERS("คำสั่งซื้อ", Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong, "nav_tab_orders"),
    TODOS("สิ่งที่ต้องทำ", Icons.Filled.Checklist, Icons.Outlined.Checklist, "nav_tab_todos"),
    REWARDS("สะสมแต้ม", Icons.Filled.CardGiftcard, Icons.Outlined.CardGiftcard, "nav_tab_rewards"),
    INFO("ร้าน", Icons.Filled.Info, Icons.Outlined.Info, "nav_tab_info")
}

@Composable
fun RimthangMainScreen(
    viewModel: CoffeeViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(RimthangTab.HOME) }

    // Observe UI States
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val filteredMenuItems by viewModel.filteredMenuItems.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val appliedPromoCode by viewModel.appliedPromoCode.collectAsStateWithLifecycle()
    val promoDiscountPercent by viewModel.promoDiscountPercent.collectAsStateWithLifecycle()
    val orderType by viewModel.orderType.collectAsStateWithLifecycle()
    val tableOrAddress by viewModel.tableOrAddress.collectAsStateWithLifecycle()
    val paymentMethod by viewModel.paymentMethod.collectAsStateWithLifecycle()
    val customizingItem by viewModel.customizingItem.collectAsStateWithLifecycle()
    val showOrderSuccess by viewModel.showOrderSuccessDialog.collectAsStateWithLifecycle()
    val lastPlacedOrder by viewModel.lastPlacedOrder.collectAsStateWithLifecycle()
    val orderHistory by viewModel.orderHistory.collectAsStateWithLifecycle()
    val favoriteIds by viewModel.favoriteIds.collectAsStateWithLifecycle()
    val rewardInfo by viewModel.rewardInfo.collectAsStateWithLifecycle()
    val filteredTodos by viewModel.filteredTodos.collectAsStateWithLifecycle()
    val allTodos by viewModel.allTodos.collectAsStateWithLifecycle()
    val todoSearchQuery by viewModel.todoSearchQuery.collectAsStateWithLifecycle()
    val selectedTodoPriorityFilter by viewModel.selectedTodoPriorityFilter.collectAsStateWithLifecycle()

    val totalCartCount = cartItems.sumOf { it.quantity }
    val activeOrdersCount = orderHistory.count { !it.status.contains("เสร็จ") && !it.status.contains("เรียบร้อย") }
    val pendingTodosCount = allTodos.count { !it.isCompleted }

    // Back handling: If on secondary tab, return to Home tab
    BackHandler(enabled = selectedTab != RimthangTab.HOME) {
        selectedTab = RimthangTab.HOME
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets(0.dp),
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                tonalElevation = 8.dp,
                windowInsets = WindowInsets.navigationBars
            ) {
                RimthangTab.values().forEach { tab ->
                    val isSelected = selectedTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        icon = {
                            if (tab == RimthangTab.CART && totalCartCount > 0) {
                                BadgedBox(
                                    badge = {
                                        Badge(containerColor = CoffeePrimary, contentColor = Color.White) {
                                            Text("$totalCartCount")
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.titleTh
                                    )
                                }
                            } else if (tab == RimthangTab.ORDERS && activeOrdersCount > 0) {
                                BadgedBox(
                                    badge = {
                                        Badge(containerColor = CremaGold, contentColor = CoffeePrimary) {
                                            Text("$activeOrdersCount")
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.titleTh
                                    )
                                }
                            } else if (tab == RimthangTab.TODOS && pendingTodosCount > 0) {
                                BadgedBox(
                                    badge = {
                                        Badge(containerColor = CoffeePrimary, contentColor = Color.White) {
                                            Text("$pendingTodosCount")
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.titleTh
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = tab.titleTh
                                )
                            }
                        },
                        label = {
                            Text(
                                text = tab.titleTh,
                                style = MaterialTheme.typography.labelSmall
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CoffeePrimary,
                            selectedTextColor = CoffeePrimary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        modifier = Modifier.testTag(tab.testTag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                RimthangTab.HOME -> {
                    HomeScreen(
                        searchQuery = searchQuery,
                        onSearchChange = viewModel::setSearchQuery,
                        selectedCategory = selectedCategory,
                        onCategorySelect = viewModel::selectCategory,
                        menuItems = filteredMenuItems,
                        bestSellers = viewModel.bestSellerItems,
                        favoriteIds = favoriteIds,
                        onToggleFavorite = viewModel::toggleFavorite,
                        onSelectForCustomization = viewModel::openCustomization,
                        onGoToCart = { selectedTab = RimthangTab.CART },
                        cartItemCount = totalCartCount,
                        onNavigateToTodos = { selectedTab = RimthangTab.TODOS }
                    )
                }
                RimthangTab.CART -> {
                    CartScreen(
                        cartItems = cartItems,
                        appliedPromoCode = appliedPromoCode,
                        promoDiscountPercent = promoDiscountPercent,
                        orderType = orderType,
                        tableOrAddress = tableOrAddress,
                        paymentMethod = paymentMethod,
                        onUpdateQuantity = viewModel::updateCartQuantity,
                        onRemoveItem = viewModel::removeCartItem,
                        onApplyPromoCode = viewModel::applyPromoCode,
                        onRemovePromoCode = viewModel::removePromoCode,
                        onSetOrderType = viewModel::setOrderType,
                        onSetTableOrAddress = viewModel::setTableOrAddress,
                        onSetPaymentMethod = viewModel::setPaymentMethod,
                        onCheckout = viewModel::placeOrder,
                        onGoToMenu = { selectedTab = RimthangTab.HOME }
                    )
                }
                RimthangTab.ORDERS -> {
                    OrdersScreen(
                        orders = orderHistory,
                        onAdvanceStatus = viewModel::advanceOrderStatus,
                        onReorder = { order ->
                            viewModel.reorder(order)
                            selectedTab = RimthangTab.CART
                        },
                        onGoToMenu = { selectedTab = RimthangTab.HOME }
                    )
                }
                RimthangTab.TODOS -> {
                    TodoScreen(
                        searchQuery = todoSearchQuery,
                        onSearchChange = viewModel::setTodoSearchQuery,
                        todos = filteredTodos,
                        allTodosCount = allTodos.size,
                        selectedPriorityFilter = selectedTodoPriorityFilter,
                        onPriorityFilterChange = viewModel::setTodoPriorityFilter,
                        onToggleTodo = viewModel::toggleTodo,
                        onDeleteTodo = viewModel::deleteTodo,
                        onAddTodo = { title, content, priority ->
                            viewModel.addTodo(title, content, priority)
                        },
                        onUpdatePriority = viewModel::updateTodoPriority
                    )
                }
                RimthangTab.REWARDS -> {
                    RewardsScreen(
                        rewardInfo = rewardInfo,
                        onRedeem = viewModel::redeemReward
                    )
                }
                RimthangTab.INFO -> {
                    ShopInfoScreen()
                }
            }
        }

        // Customization Bottom Sheet
        if (customizingItem != null) {
            CustomizationSheet(
                item = customizingItem!!,
                onDismiss = viewModel::closeCustomization,
                onAddToCart = { item, type, sweetness, roast, toppings, note, qty ->
                    viewModel.addToCart(item, type, sweetness, roast, toppings, note, qty)
                }
            )
        }

        // Order Success Dialog
        if (showOrderSuccess && lastPlacedOrder != null) {
            OrderSuccessDialog(
                order = lastPlacedOrder!!,
                onDismiss = viewModel::dismissOrderSuccessDialog,
                onViewOrders = {
                    selectedTab = RimthangTab.ORDERS
                }
            )
        }
    }
}
