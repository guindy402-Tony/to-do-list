package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.example.data.model.CoffeeCategory
import com.example.data.model.CoffeeItem
import com.example.ui.theme.CoffeePrimary
import com.example.ui.theme.CremaGold
import com.example.ui.theme.MatchaGreen

@Composable
fun CoffeeItemIllustration(
    item: CoffeeItem,
    modifier: Modifier = Modifier,
    size: Dp = 100.dp
) {
    val bgBrush = when (item.category) {
        CoffeeCategory.COFFEE -> Brush.verticalGradient(
            colors = listOf(Color(0xFF5D3823), Color(0xFF2C160B))
        )
        CoffeeCategory.TEA_MILK -> {
            if (item.nameTh.contains("มัทฉะ")) {
                Brush.verticalGradient(listOf(Color(0xFF6B8E23), Color(0xFF3B5311)))
            } else if (item.nameTh.contains("ชาไทย")) {
                Brush.verticalGradient(listOf(Color(0xFFE66A23), Color(0xFF9E3E07)))
            } else {
                Brush.verticalGradient(listOf(Color(0xFF5D7B93), Color(0xFF263D52)))
            }
        }
        CoffeeCategory.REFRESHER -> {
            if (item.nameTh.contains("ยูซุ") || item.nameTh.contains("ส้ม")) {
                Brush.verticalGradient(listOf(Color(0xFFFF9E2C), Color(0xFFD66005)))
            } else if (item.nameTh.contains("อัญชัน")) {
                Brush.verticalGradient(listOf(Color(0xFF673AB7), Color(0xFF3F51B5)))
            } else {
                Brush.verticalGradient(listOf(Color(0xFFE91E63), Color(0xFF880E4F)))
            }
        }
        CoffeeCategory.BAKERY -> Brush.verticalGradient(
            colors = listOf(Color(0xFFDE9E48), Color(0xFF9C5B17))
        )
        else -> Brush.verticalGradient(listOf(CoffeePrimary, Color(0xFF211108)))
    }

    val context = LocalContext.current
    val boxModifier = if (modifier == Modifier) Modifier.size(size) else modifier

    Box(
        modifier = boxModifier
            .clip(RoundedCornerShape(18.dp))
            .background(bgBrush),
        contentAlignment = Alignment.Center
    ) {
        if (item.imageUrl.isNotBlank()) {
            SubcomposeAsyncImage(
                model = ImageRequest.Builder(context)
                    .data(item.imageUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = item.nameTh,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                loading = {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(bgBrush),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(size * 0.3f),
                            color = CremaGold,
                            strokeWidth = 2.dp
                        )
                    }
                },
                error = {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(bgBrush),
                        contentAlignment = Alignment.Center
                    ) {
                        when (item.category) {
                            CoffeeCategory.COFFEE -> CoffeeCupCanvas(size = size * 0.75f)
                            CoffeeCategory.TEA_MILK -> TeaCupCanvas(isMatcha = item.nameTh.contains("มัทฉะ"), size = size * 0.75f)
                            CoffeeCategory.REFRESHER -> SodaCanvas(size = size * 0.75f)
                            CoffeeCategory.BAKERY -> BakeryCanvas(size = size * 0.75f)
                            else -> CoffeeCupCanvas(size = size * 0.75f)
                        }
                    }
                }
            )
        } else {
            when (item.category) {
                CoffeeCategory.COFFEE -> CoffeeCupCanvas(size = size * 0.75f)
                CoffeeCategory.TEA_MILK -> TeaCupCanvas(isMatcha = item.nameTh.contains("มัทฉะ"), size = size * 0.75f)
                CoffeeCategory.REFRESHER -> SodaCanvas(size = size * 0.75f)
                CoffeeCategory.BAKERY -> BakeryCanvas(size = size * 0.75f)
                else -> CoffeeCupCanvas(size = size * 0.75f)
            }
        }
    }
}

@Composable
fun CoffeeCupCanvas(size: Dp = 80.dp) {
    Canvas(modifier = Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        // Saucer
        drawRoundRect(
            color = Color(0x66FFFFFF),
            topLeft = Offset(w * 0.15f, h * 0.82f),
            size = Size(w * 0.7f, h * 0.12f),
            cornerRadius = CornerRadius(h * 0.06f, h * 0.06f)
        )

        // Cup Path
        val cupPath = Path().apply {
            moveTo(w * 0.22f, h * 0.35f)
            lineTo(w * 0.78f, h * 0.35f)
            cubicTo(
                w * 0.76f, h * 0.72f,
                w * 0.65f, h * 0.82f,
                w * 0.5f, h * 0.82f
            )
            cubicTo(
                w * 0.35f, h * 0.82f,
                w * 0.24f, h * 0.72f,
                w * 0.22f, h * 0.35f
            )
            close()
        }
        drawPath(cupPath, Color.White)

        // Coffee Crema
        drawOval(
            color = Color(0xFFC78942),
            topLeft = Offset(w * 0.25f, h * 0.36f),
            size = Size(w * 0.5f, h * 0.18f)
        )

        // Latte Heart
        val heartPath = Path().apply {
            moveTo(w * 0.5f, h * 0.49f)
            cubicTo(w * 0.42f, h * 0.42f, w * 0.40f, h * 0.38f, w * 0.46f, h * 0.38f)
            cubicTo(w * 0.5f, h * 0.38f, w * 0.5f, h * 0.42f, w * 0.5f, h * 0.42f)
            cubicTo(w * 0.5f, h * 0.42f, w * 0.5f, h * 0.38f, w * 0.54f, h * 0.38f)
            cubicTo(w * 0.60f, h * 0.38f, w * 0.58f, h * 0.42f, w * 0.5f, h * 0.49f)
            close()
        }
        drawPath(heartPath, Color(0xFFFFF3E0))

        // Cup Handle
        val handlePath = Path().apply {
            moveTo(w * 0.75f, h * 0.42f)
            cubicTo(w * 0.95f, h * 0.44f, w * 0.93f, h * 0.68f, w * 0.72f, h * 0.70f)
        }
        drawPath(
            handlePath,
            color = Color.White,
            style = Stroke(width = w * 0.08f, cap = StrokeCap.Round)
        )

        // Steam Lines
        drawLine(
            color = Color(0xAAFFF8E7),
            start = Offset(w * 0.4f, h * 0.28f),
            end = Offset(w * 0.38f, h * 0.14f),
            strokeWidth = w * 0.04f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color(0xDDFFFFFF),
            start = Offset(w * 0.5f, h * 0.26f),
            end = Offset(w * 0.52f, h * 0.10f),
            strokeWidth = w * 0.045f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color(0xAAFFF8E7),
            start = Offset(w * 0.6f, h * 0.28f),
            end = Offset(w * 0.62f, h * 0.14f),
            strokeWidth = w * 0.04f,
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun TeaCupCanvas(isMatcha: Boolean, size: Dp = 80.dp) {
    Canvas(modifier = Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        // Tall Glass
        val glassPath = Path().apply {
            moveTo(w * 0.26f, h * 0.18f)
            lineTo(w * 0.74f, h * 0.18f)
            lineTo(w * 0.68f, h * 0.88f)
            cubicTo(w * 0.68f, h * 0.92f, w * 0.32f, h * 0.92f, w * 0.32f, h * 0.88f)
            close()
        }
        drawPath(glassPath, Color(0x33FFFFFF))

        // Tea Layer
        val liquidColor = if (isMatcha) Color(0xFF7AA543) else Color(0xFFFF8533)
        val teaPath = Path().apply {
            moveTo(w * 0.28f, h * 0.36f)
            lineTo(w * 0.72f, h * 0.36f)
            lineTo(w * 0.67f, h * 0.86f)
            cubicTo(w * 0.67f, h * 0.90f, w * 0.33f, h * 0.90f, w * 0.33f, h * 0.86f)
            close()
        }
        drawPath(teaPath, liquidColor)

        // Milk Cream Layer on top
        drawRoundRect(
            color = Color(0xFFFFF9F0),
            topLeft = Offset(w * 0.27f, h * 0.28f),
            size = Size(w * 0.46f, h * 0.16f),
            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
        )

        // Straw
        drawLine(
            color = Color(0xFFFAF0CA),
            start = Offset(w * 0.62f, h * 0.06f),
            end = Offset(w * 0.42f, h * 0.85f),
            strokeWidth = w * 0.05f,
            cap = StrokeCap.Round
        )

        // Ice cubes
        drawRoundRect(
            color = Color(0x66FFFFFF),
            topLeft = Offset(w * 0.36f, h * 0.46f),
            size = Size(w * 0.16f, h * 0.16f),
            cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
        )
        drawRoundRect(
            color = Color(0x66FFFFFF),
            topLeft = Offset(w * 0.50f, h * 0.54f),
            size = Size(w * 0.16f, h * 0.16f),
            cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
        )
    }
}

@Composable
fun SodaCanvas(size: Dp = 80.dp) {
    Canvas(modifier = Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        // Soda Cup
        val cupPath = Path().apply {
            moveTo(w * 0.25f, h * 0.22f)
            lineTo(w * 0.75f, h * 0.22f)
            lineTo(w * 0.68f, h * 0.88f)
            cubicTo(w * 0.68f, h * 0.92f, w * 0.32f, h * 0.92f, w * 0.32f, h * 0.88f)
            close()
        }
        drawPath(cupPath, Color(0xFFFFF7EB))

        // Citrus Slice
        drawCircle(
            color = Color(0xFFFFD54F),
            radius = w * 0.16f,
            center = Offset(w * 0.70f, h * 0.26f)
        )
        drawCircle(
            color = Color(0xFFFFF9C4),
            radius = w * 0.12f,
            center = Offset(w * 0.70f, h * 0.26f)
        )

        // Mint leaf
        val mintPath = Path().apply {
            moveTo(w * 0.38f, h * 0.22f)
            cubicTo(w * 0.32f, h * 0.12f, w * 0.44f, h * 0.08f, w * 0.50f, h * 0.16f)
            cubicTo(w * 0.46f, h * 0.22f, w * 0.42f, h * 0.24f, w * 0.38f, h * 0.22f)
            close()
        }
        drawPath(mintPath, Color(0xFF4CAF50))

        // Soda bubbles
        val bubbleColor = Color(0x88FFFFFF)
        drawCircle(bubbleColor, w * 0.03f, Offset(w * 0.42f, h * 0.45f))
        drawCircle(bubbleColor, w * 0.04f, Offset(w * 0.58f, h * 0.52f))
        drawCircle(bubbleColor, w * 0.025f, Offset(w * 0.46f, h * 0.65f))
        drawCircle(bubbleColor, w * 0.035f, Offset(w * 0.54f, h * 0.75f))

        // Striped straw
        drawLine(
            color = Color(0xFFFF5252),
            start = Offset(w * 0.56f, h * 0.05f),
            end = Offset(w * 0.40f, h * 0.82f),
            strokeWidth = w * 0.045f,
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun BakeryCanvas(size: Dp = 80.dp) {
    Canvas(modifier = Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        // Golden Crescent / Croissant
        val croissantPath = Path().apply {
            moveTo(w * 0.15f, h * 0.65f)
            cubicTo(w * 0.25f, h * 0.30f, w * 0.75f, h * 0.30f, w * 0.85f, h * 0.65f)
            cubicTo(w * 0.72f, h * 0.55f, w * 0.60f, h * 0.68f, w * 0.50f, h * 0.72f)
            cubicTo(w * 0.40f, h * 0.68f, w * 0.28f, h * 0.55f, w * 0.15f, h * 0.65f)
            close()
        }
        drawPath(croissantPath, Color(0xFFFFD580))

        // Golden Flakes / Ribs
        val rib1 = Path().apply {
            moveTo(w * 0.35f, h * 0.42f)
            cubicTo(w * 0.42f, h * 0.48f, w * 0.44f, h * 0.62f, w * 0.42f, h * 0.68f)
        }
        drawPath(rib1, Color(0xFFC77A1C), style = Stroke(width = w * 0.04f, cap = StrokeCap.Round))

        val rib2 = Path().apply {
            moveTo(w * 0.50f, h * 0.36f)
            cubicTo(w * 0.52f, h * 0.45f, w * 0.52f, h * 0.60f, w * 0.50f, h * 0.70f)
        }
        drawPath(rib2, Color(0xFFB5651D), style = Stroke(width = w * 0.045f, cap = StrokeCap.Round))

        val rib3 = Path().apply {
            moveTo(w * 0.65f, h * 0.42f)
            cubicTo(w * 0.58f, h * 0.48f, w * 0.56f, h * 0.62f, w * 0.58f, h * 0.68f)
        }
        drawPath(rib3, Color(0xFFC77A1C), style = Stroke(width = w * 0.04f, cap = StrokeCap.Round))

        // Shine highlight
        drawCircle(
            color = Color(0x66FFFFFF),
            radius = w * 0.05f,
            center = Offset(w * 0.46f, h * 0.42f)
        )
    }
}
