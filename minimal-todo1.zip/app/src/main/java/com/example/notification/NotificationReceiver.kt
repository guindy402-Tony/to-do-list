package com.example.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(NotificationHelper.EXTRA_TODO_ID, 0L)
        val title = intent.getStringExtra(NotificationHelper.EXTRA_TODO_TITLE) ?: "เตือนความจำ"
        val note = intent.getStringExtra(NotificationHelper.EXTRA_TODO_NOTE) ?: ""

        NotificationHelper.showNotification(
            context = context,
            id = id,
            title = "⏰ $title",
            note = note
        )
    }
}
