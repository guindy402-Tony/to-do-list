package com.example.data.repository

import com.example.data.local.TodoDao
import com.example.data.model.TodoItem
import kotlinx.coroutines.flow.Flow

class TodoRepository(private val todoDao: TodoDao) {
    val allTodos: Flow<List<TodoItem>> = todoDao.getAllTodos()
    val activeTodos: Flow<List<TodoItem>> = todoDao.getActiveTodos()
    val completedTodos: Flow<List<TodoItem>> = todoDao.getCompletedTodos()

    suspend fun insert(todo: TodoItem): Long = todoDao.insertTodo(todo)

    suspend fun update(todo: TodoItem) = todoDao.updateTodo(todo)

    suspend fun delete(todo: TodoItem) = todoDao.deleteTodo(todo)

    suspend fun deleteById(id: Long) = todoDao.deleteTodoById(id)

    suspend fun clearCompleted() = todoDao.deleteCompletedTodos()

    suspend fun toggleCompleted(todo: TodoItem) {
        val updated = todo.copy(
            isCompleted = !todo.isCompleted,
            completedAt = if (!todo.isCompleted) System.currentTimeMillis() else null
        )
        todoDao.updateTodo(updated)
    }

    suspend fun ensureInitialData() {
        if (todoDao.getCount() == 0) {
            val sampleItems = listOf(
                TodoItem(
                    title = "ยินดีต้อนรับสู่ Minimal Todo 🤍",
                    note = "แอปจดบันทึกสิ่งที่ต้องทำ ดีไซน์เรียบง่าย ขาว-ฟ้า สบายตา",
                    category = "ทั่วไป",
                    priority = "ปกติ",
                    isCompleted = false
                ),
                TodoItem(
                    title = "แตะวงกลมเพื่อทำเครื่องหมายว่าเสร็จแล้ว",
                    note = "บันทึกข้อมูลลงฐานข้อมูลเครื่องอัตโนมัติ (Local Room DB)",
                    category = "ทั่วไป",
                    priority = "ปกติ",
                    isCompleted = false
                ),
                TodoItem(
                    title = "ดื่มน้ำเปล่าให้สดชื่น 8 แก้ววันนี้ 💧",
                    note = "เพื่อสุขภาพและความสดชื่นระหว่างวัน",
                    category = "ส่วนตัว",
                    priority = "สำคัญมาก",
                    isCompleted = false
                ),
                TodoItem(
                    title = "ออกแบบและเขียนโค้ดสำหรับโปรเจกต์ใหม่ 💻",
                    note = "เน้นความเรียบง่าย สบายตา และใช้งานง่ายที่สุด",
                    category = "งาน",
                    priority = "สำคัญมาก",
                    isCompleted = true,
                    completedAt = System.currentTimeMillis()
                )
            )
            todoDao.insertTodos(sampleItems)
        }
    }
}
