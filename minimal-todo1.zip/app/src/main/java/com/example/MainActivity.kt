package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.repository.TodoRepository
import com.example.ui.TodoScreen
import com.example.ui.TodoViewModel
import com.example.ui.TodoViewModelFactory
import com.example.ui.theme.MinimalTodoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        com.example.notification.NotificationHelper.createNotificationChannel(applicationContext)

        val database = AppDatabase.getDatabase(applicationContext)
        val repository = TodoRepository(database.todoDao())

        setContent {
            MinimalTodoTheme {
                val viewModel: TodoViewModel = viewModel(
                    factory = TodoViewModelFactory(repository)
                )
                TodoScreen(viewModel = viewModel)
            }
        }
    }
}
