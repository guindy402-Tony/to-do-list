package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.notification.NotificationHelper
import com.example.ui.components.MinimalAddEditSheet
import com.example.ui.components.MinimalEmptyState
import com.example.ui.components.MinimalFilterTabs
import com.example.ui.components.MinimalHeader
import com.example.ui.components.MinimalQuickAddBar
import com.example.ui.components.MinimalTodoItemCard
import com.example.ui.components.SwipeableTodoItem
import com.example.ui.theme.PureWhite

@Composable
fun TodoScreen(
    viewModel: TodoViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var hasNotificationPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasNotificationPermission = isGranted
    }

    val ensureNotificationPermission = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("todo_screen"),
        containerColor = PureWhite,
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            ) {
                MinimalQuickAddBar(
                    selectedCategory = state.selectedCategory,
                    onQuickAdd = { title ->
                        viewModel.addTodo(
                            title = title,
                            category = if (state.selectedCategory != "ทั้งหมด") state.selectedCategory else "ทั่วไป"
                        )
                    },
                    onOpenFullAdd = {
                        viewModel.setAddSheetOpen(true)
                    }
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = innerPadding.calculateTopPadding())
                .background(PureWhite)
        ) {
            // Header: Date, App Title, Actions, Progress bar
            MinimalHeader(
                totalCount = state.totalCount,
                completedCount = state.completedCount,
                completionPercentage = state.completionPercentage,
                isSearchOpen = state.isSearchOpen,
                searchQuery = state.searchQuery,
                onSearchQueryChange = { viewModel.setSearchQuery(it) },
                onToggleSearch = { viewModel.toggleSearch() },
                onClearCompleted = { viewModel.clearCompleted() },
                onTestNotification = {
                    ensureNotificationPermission()
                    NotificationHelper.showNotification(
                        context = context,
                        id = System.currentTimeMillis(),
                        title = "Minimal Todo 🤍",
                        note = "ทดสอบการแจ้งเตือนสำเร็จแล้ว! ระบบเตือนความจำพร้อมทำงานบนมือถือของคุณ"
                    )
                }
            )

            // Status Filter Tabs & Category Filter Chips with counts & add category
            MinimalFilterTabs(
                currentFilter = state.currentFilter,
                onFilterSelect = { viewModel.setFilter(it) },
                selectedCategory = state.selectedCategory,
                availableCategories = state.availableCategories,
                categoryCounts = state.categoryActiveCounts,
                onCategorySelect = { viewModel.setCategory(it) },
                onAddCategory = { viewModel.addCategory(it) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Todo Items List
            if (state.items.isEmpty()) {
                MinimalEmptyState(
                    currentFilter = state.currentFilter,
                    selectedCategory = state.selectedCategory
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("todo_list"),
                    contentPadding = PaddingValues(
                        start = 20.dp,
                        end = 20.dp,
                        top = 8.dp,
                        bottom = innerPadding.calculateBottomPadding() + 80.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(
                        items = state.items,
                        key = { it.id }
                    ) { item ->
                        SwipeableTodoItem(
                            item = item,
                            onToggle = {
                                if (!item.isCompleted && item.dueDate != null) {
                                    NotificationHelper.cancelNotification(context, item.id)
                                }
                                viewModel.toggleTodo(item)
                            },
                            onEdit = { viewModel.setEditingItem(item) },
                            onDelete = {
                                NotificationHelper.cancelNotification(context, item.id)
                                viewModel.deleteTodo(item)
                            }
                        )
                    }
                }
            }
        }
    }

    // Add New Task Sheet
    if (state.isAddSheetOpen) {
        MinimalAddEditSheet(
            initialItem = null,
            categories = state.availableCategories,
            defaultCategory = state.selectedCategory,
            onDismiss = { viewModel.setAddSheetOpen(false) },
            onSave = { title, note, category, priority, dueDate ->
                if (dueDate != null) {
                    ensureNotificationPermission()
                }
                viewModel.addTodo(
                    title = title,
                    note = note,
                    category = category,
                    priority = priority,
                    dueDate = dueDate,
                    onInserted = { newId ->
                        if (dueDate != null) {
                            NotificationHelper.scheduleNotification(
                                context = context,
                                id = newId,
                                title = title,
                                note = note,
                                triggerAtMillis = dueDate
                            )
                        }
                    }
                )
                viewModel.setAddSheetOpen(false)
            }
        )
    }

    // Edit Existing Task Sheet
    state.editingItem?.let { itemToEdit ->
        MinimalAddEditSheet(
            initialItem = itemToEdit,
            categories = state.availableCategories,
            defaultCategory = itemToEdit.category,
            onDismiss = { viewModel.setEditingItem(null) },
            onSave = { title, note, category, priority, dueDate ->
                if (dueDate != null) {
                    ensureNotificationPermission()
                    NotificationHelper.scheduleNotification(
                        context = context,
                        id = itemToEdit.id,
                        title = title,
                        note = note,
                        triggerAtMillis = dueDate
                    )
                } else if (itemToEdit.dueDate != null) {
                    NotificationHelper.cancelNotification(context, itemToEdit.id)
                }

                viewModel.updateTodo(
                    itemToEdit.copy(
                        title = title,
                        note = note,
                        category = category,
                        priority = priority,
                        dueDate = dueDate
                    )
                )
                viewModel.setEditingItem(null)
            }
        )
    }
}
