package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.TodoItem
import com.example.data.repository.TodoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class TodoFilter(val label: String) {
    ALL("ทั้งหมด"),
    ACTIVE("ที่ต้องทำ"),
    COMPLETED("เสร็จแล้ว")
}

data class FilterCriteria(
    val filter: TodoFilter = TodoFilter.ALL,
    val category: String = "ทั้งหมด",
    val searchQuery: String = ""
)

data class TodoUiState(
    val items: List<TodoItem> = emptyList(),
    val totalCount: Int = 0,
    val activeCount: Int = 0,
    val completedCount: Int = 0,
    val completionPercentage: Float = 0f,
    val currentFilter: TodoFilter = TodoFilter.ALL,
    val selectedCategory: String = "ทั้งหมด",
    val availableCategories: List<String> = listOf("ทั้งหมด", "งาน", "ส่วนตัว", "ช้อปปิ้ง", "สุขภาพ", "การเงิน", "ทั่วไป"),
    val categoryActiveCounts: Map<String, Int> = emptyMap(),
    val searchQuery: String = "",
    val isSearchOpen: Boolean = false,
    val editingItem: TodoItem? = null,
    val isAddSheetOpen: Boolean = false
)

class TodoViewModel(private val repository: TodoRepository) : ViewModel() {

    private val _filterCriteria = MutableStateFlow(FilterCriteria())
    private val _isSearchOpen = MutableStateFlow(false)
    private val _editingItem = MutableStateFlow<TodoItem?>(null)
    private val _isAddSheetOpen = MutableStateFlow(false)
    private val _customCategories = MutableStateFlow<List<String>>(emptyList())

    init {
        viewModelScope.launch {
            repository.ensureInitialData()
        }
    }

    val uiState: StateFlow<TodoUiState> = combine(
        repository.allTodos,
        _filterCriteria,
        _isSearchOpen,
        _editingItem,
        combine(_isAddSheetOpen, _customCategories) { isAddOpen, customCats -> Pair(isAddOpen, customCats) }
    ) { allItems, criteria, isSearch, editing, (isAddOpen, customCats) ->
        val total = allItems.size
        val completed = allItems.count { it.isCompleted }
        val active = total - completed
        val progress = if (total > 0) completed.toFloat() / total.toFloat() else 0f

        // Calculate active item counts per category
        val categoryCounts = mutableMapOf<String, Int>()
        categoryCounts["ทั้งหมด"] = active
        allItems.filter { !it.isCompleted }.forEach { item ->
            categoryCounts[item.category] = (categoryCounts[item.category] ?: 0) + 1
        }

        val allCategories = (listOf("ทั้งหมด", "งาน", "ส่วนตัว", "ช้อปปิ้ง", "สุขภาพ", "การเงิน", "ทั่วไป") +
                allItems.map { it.category } +
                customCats).distinct()

        val filteredItems = allItems.filter { item ->
            // Filter by status
            val statusMatches = when (criteria.filter) {
                TodoFilter.ALL -> true
                TodoFilter.ACTIVE -> !item.isCompleted
                TodoFilter.COMPLETED -> item.isCompleted
            }

            // Filter by category
            val categoryMatches = if (criteria.category == "ทั้งหมด") true else item.category == criteria.category

            // Filter by search query
            val queryMatches = if (criteria.searchQuery.isBlank()) {
                true
            } else {
                item.title.contains(criteria.searchQuery, ignoreCase = true) ||
                        item.note.contains(criteria.searchQuery, ignoreCase = true) ||
                        item.category.contains(criteria.searchQuery, ignoreCase = true)
            }

            statusMatches && categoryMatches && queryMatches
        }

        TodoUiState(
            items = filteredItems,
            totalCount = total,
            activeCount = active,
            completedCount = completed,
            completionPercentage = progress,
            currentFilter = criteria.filter,
            selectedCategory = criteria.category,
            availableCategories = allCategories,
            categoryActiveCounts = categoryCounts,
            searchQuery = criteria.searchQuery,
            isSearchOpen = isSearch,
            editingItem = editing,
            isAddSheetOpen = isAddOpen
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TodoUiState()
    )

    fun setFilter(filter: TodoFilter) {
        _filterCriteria.value = _filterCriteria.value.copy(filter = filter)
    }

    fun setCategory(category: String) {
        _filterCriteria.value = _filterCriteria.value.copy(category = category)
    }

    fun addCategory(category: String) {
        val trimmed = category.trim()
        if (trimmed.isNotBlank() && !_customCategories.value.contains(trimmed)) {
            _customCategories.value = _customCategories.value + trimmed
            setCategory(trimmed)
        }
    }

    fun setSearchQuery(query: String) {
        _filterCriteria.value = _filterCriteria.value.copy(searchQuery = query)
    }

    fun toggleSearch() {
        val willOpen = !_isSearchOpen.value
        _isSearchOpen.value = willOpen
        if (!willOpen) {
            _filterCriteria.value = _filterCriteria.value.copy(searchQuery = "")
        }
    }

    fun setEditingItem(item: TodoItem?) {
        _editingItem.value = item
    }

    fun setAddSheetOpen(isOpen: Boolean) {
        _isAddSheetOpen.value = isOpen
    }

    fun addTodo(
        title: String,
        note: String = "",
        category: String = "ทั่วไป",
        priority: String = "ปกติ",
        dueDate: Long? = null,
        onInserted: ((Long) -> Unit)? = null
    ) {
        if (title.isBlank()) return
        viewModelScope.launch {
            val id = repository.insert(
                TodoItem(
                    title = title.trim(),
                    note = note.trim(),
                    category = category.ifBlank { "ทั่วไป" },
                    priority = priority,
                    dueDate = dueDate,
                    isCompleted = false
                )
            )
            onInserted?.invoke(id)
        }
    }

    fun toggleTodo(item: TodoItem) {
        viewModelScope.launch {
            repository.toggleCompleted(item)
        }
    }

    fun updateTodo(item: TodoItem) {
        viewModelScope.launch {
            repository.update(item)
        }
    }

    fun deleteTodo(item: TodoItem) {
        viewModelScope.launch {
            repository.delete(item)
        }
    }

    fun clearCompleted() {
        viewModelScope.launch {
            repository.clearCompleted()
        }
    }
}

class TodoViewModelFactory(private val repository: TodoRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TodoViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return TodoViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
