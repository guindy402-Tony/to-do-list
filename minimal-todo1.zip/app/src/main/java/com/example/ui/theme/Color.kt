package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Sky & Azure Blues
val SkyPrimary = Color(0xFF0284C7)
val SkyPrimaryLight = Color(0xFF38BDF8)
val SkyPrimaryDark = Color(0xFF0369A1)
val SkyContainer = Color(0xFFE0F2FE)
val OnSkyContainer = Color(0xFF075985)

// Neutral & Minimal Surfaces
val PureWhite = Color(0xFFFFFFFF)
val OffWhite = Color(0xFFF8FAFC)
val SurfaceSoft = Color(0xFFF1F5F9)
val BorderSubtle = Color(0xFFE2E8F0)
val BorderLight = Color(0xFFF1F5F9)

// Text Slate Palette
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF64748B)
val TextMuted = Color(0xFF94A3B8)
val TextDisabled = Color(0xFFCBD5E1)

// Accent / Priority Colors (Subtle & clean)
val PriorityHigh = Color(0xFFF43F5E)
val PriorityMedium = Color(0xFFF59E0B)
val PriorityLow = Color(0xFF0EA5E9)

// Dark Theme Variants
val DarkBackground = Color(0xFF0B132B)
val DarkSurface = Color(0xFF1C2541)
val DarkSurfaceSubtle = Color(0xFF232F4F)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkBorder = Color(0xFF2E3E66)
