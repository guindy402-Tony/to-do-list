package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.WorkOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TodoItem
import com.example.ui.TodoFilter
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object CategoryHelper {
    data class Info(
        val name: String,
        val icon: ImageVector,
        val primaryColor: Color,
        val containerColor: Color
    )

    fun getInfo(category: String): Info {
        return when (category) {
            "งาน", "Work" -> Info(
                name = "งาน",
                icon = Icons.Outlined.WorkOutline,
                primaryColor = Color(0xFF1976D2), // Blue
                containerColor = Color(0xFFE3F2FD)
            )
            "ส่วนตัว", "Personal" -> Info(
                name = "ส่วนตัว",
                icon = Icons.Outlined.Person,
                primaryColor = Color(0xFF2E7D32), // Forest Green
                containerColor = Color(0xFFE8F5E9)
            )
            "ช้อปปิ้ง", "Shopping" -> Info(
                name = "ช้อปปิ้ง",
                icon = Icons.Outlined.ShoppingCart,
                primaryColor = Color(0xFFE65100), // Vibrant Orange
                containerColor = Color(0xFFFFF3E0)
            )
            "สุขภาพ", "Health" -> Info(
                name = "สุขภาพ",
                icon = Icons.Outlined.FavoriteBorder,
                primaryColor = Color(0xFFC2185B), // Berry Pink
                containerColor = Color(0xFFFCE4EC)
            )
            "การเงิน", "Finance" -> Info(
                name = "การเงิน",
                icon = Icons.Outlined.Payments,
                primaryColor = Color(0xFF00796B), // Deep Teal
                containerColor = Color(0xFFE0F2F1)
            )
            "ทั่วไป", "General" -> Info(
                name = "ทั่วไป",
                icon = Icons.Outlined.Assignment,
                primaryColor = Color(0xFF546E7A), // Slate
                containerColor = Color(0xFFECEFF1)
            )
            "ทั้งหมด" -> Info(
                name = "ทั้งหมด",
                icon = Icons.Outlined.Category,
                primaryColor = SkyPrimary,
                containerColor = SkyContainer
            )
            else -> Info(
                name = category,
                icon = Icons.Outlined.Folder,
                primaryColor = Color(0xFF6A1B9A), // Purple for custom
                containerColor = Color(0xFFF3E5F5)
            )
        }
    }
}

fun formatReminderBadge(timestamp: Long): String {
    val now = Calendar.getInstance()
    val reminderCal = Calendar.getInstance().apply { timeInMillis = timestamp }

    val isToday = now.get(Calendar.YEAR) == reminderCal.get(Calendar.YEAR) &&
            now.get(Calendar.DAY_OF_YEAR) == reminderCal.get(Calendar.DAY_OF_YEAR)

    val tomorrow = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }
    val isTomorrow = tomorrow.get(Calendar.YEAR) == reminderCal.get(Calendar.YEAR) &&
            tomorrow.get(Calendar.DAY_OF_YEAR) == reminderCal.get(Calendar.DAY_OF_YEAR)

    val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    val timeStr = timeFormat.format(Date(timestamp))

    return when {
        isToday -> "วันนี้ $timeStr"
        isTomorrow -> "พรุ่งนี้ $timeStr"
        else -> {
            val dateFormat = SimpleDateFormat("d MMM, HH:mm", Locale("th", "TH"))
            dateFormat.format(Date(timestamp))
        }
    }
}

@Composable
fun MinimalHeader(
    totalCount: Int,
    completedCount: Int,
    completionPercentage: Float,
    isSearchOpen: Boolean,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onToggleSearch: () -> Unit,
    onClearCompleted: () -> Unit,
    onTestNotification: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }
    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(PureWhite)
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        if (isSearchOpen) {
            // Minimal Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = {
                    Text(
                        text = "ค้นหาสิ่งที่ต้องทำหรือหมวดหมู่...",
                        color = TextMuted,
                        fontSize = 15.sp
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "ค้นหา",
                        tint = SkyPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                },
                trailingIcon = {
                    IconButton(onClick = {
                        keyboardController?.hide()
                        focusManager.clearFocus()
                        onToggleSearch()
                    }) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "ปิดการค้นหา",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SkyPrimary,
                    unfocusedBorderColor = BorderSubtle,
                    focusedContainerColor = OffWhite,
                    unfocusedContainerColor = OffWhite,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_text_field")
            )
        } else {
            // Minimal Top Bar with Date & Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    val dateFormat = remember {
                        SimpleDateFormat("EEEE, d MMMM", Locale("th", "TH"))
                    }
                    val todayDate = remember { dateFormat.format(Date()) }

                    Text(
                        text = todayDate,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 0.5.sp
                        ),
                        color = SkyPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "สิ่งที่ต้องทำ",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = (-0.5).sp
                        ),
                        color = TextPrimary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onToggleSearch,
                        modifier = Modifier.testTag("search_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "ค้นหา",
                            tint = TextSecondary
                        )
                    }

                    Box {
                        IconButton(
                            onClick = { showMenu = true },
                            modifier = Modifier.testTag("menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "ตัวเลือกเพิ่มเติม",
                                tint = TextSecondary
                            )
                        }

                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            modifier = Modifier.background(PureWhite)
                        ) {
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "ทดสอบส่งการแจ้งเตือน 🔔",
                                        color = SkyPrimary,
                                        fontSize = 14.sp
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Outlined.Notifications,
                                        contentDescription = null,
                                        tint = SkyPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                onClick = {
                                    showMenu = false
                                    onTestNotification()
                                }
                            )

                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "ล้างงานที่ทำเสร็จแล้ว",
                                        color = PriorityHigh,
                                        fontSize = 14.sp
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Outlined.DeleteOutline,
                                        contentDescription = null,
                                        tint = PriorityHigh,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                onClick = {
                                    showMenu = false
                                    onClearCompleted()
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Sleek Minimal Progress Bar
            if (totalCount > 0) {
                val animatedProgress by animateFloatAsState(
                    targetValue = completionPercentage,
                    animationSpec = tween(durationMillis = 400),
                    label = "progress_animation"
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(OffWhite, RoundedCornerShape(12.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ความคืบหน้า",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        Text(
                            text = "เสร็จแล้ว $completedCount/$totalCount รายการ (${(animatedProgress * 100).toInt()}%)",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = SkyPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = SkyPrimary,
                        trackColor = BorderLight,
                        strokeCap = StrokeCap.Round
                    )
                }
            }
        }
    }
}

@Composable
fun MinimalFilterTabs(
    currentFilter: TodoFilter,
    onFilterSelect: (TodoFilter) -> Unit,
    selectedCategory: String,
    availableCategories: List<String>,
    categoryCounts: Map<String, Int>,
    onCategorySelect: (String) -> Unit,
    onAddCategory: (String) -> Unit
) {
    var showAddCategoryDialog by remember { mutableStateOf(false) }
    var newCategoryText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(PureWhite)
            .padding(horizontal = 20.dp, vertical = 4.dp)
    ) {
        // Status Tabs (All, Active, Completed)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(OffWhite, RoundedCornerShape(10.dp))
                .padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            TodoFilter.entries.forEach { filter ->
                val isSelected = currentFilter == filter
                val bgColor by animateColorAsState(
                    targetValue = if (isSelected) PureWhite else Color.Transparent,
                    label = "tab_bg"
                )
                val textColor by animateColorAsState(
                    targetValue = if (isSelected) SkyPrimary else TextSecondary,
                    label = "tab_text"
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(bgColor)
                        .clickable { onFilterSelect(filter) }
                        .padding(vertical = 7.dp)
                        .testTag("filter_tab_${filter.name.lowercase()}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = filter.label,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                        ),
                        color = textColor
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Categories Row with Icons, Counts, and Distinct Colors
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            availableCategories.forEach { category ->
                val isCatSelected = selectedCategory == category
                val catInfo = CategoryHelper.getInfo(category)
                val count = categoryCounts[category] ?: 0

                val catBg by animateColorAsState(
                    targetValue = if (isCatSelected) catInfo.containerColor else OffWhite,
                    label = "cat_chip_bg"
                )
                val catBorderColor by animateColorAsState(
                    targetValue = if (isCatSelected) catInfo.primaryColor else BorderSubtle,
                    label = "cat_chip_border"
                )
                val catTextColor by animateColorAsState(
                    targetValue = if (isCatSelected) catInfo.primaryColor else TextSecondary,
                    label = "cat_chip_text"
                )

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = catBg,
                    border = androidx.compose.foundation.BorderStroke(1.dp, catBorderColor),
                    modifier = Modifier
                        .clickable { onCategorySelect(category) }
                        .testTag("category_chip_$category")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = catInfo.icon,
                            contentDescription = null,
                            tint = catTextColor,
                            modifier = Modifier.size(15.dp)
                        )

                        Text(
                            text = category,
                            fontSize = 12.sp,
                            fontWeight = if (isCatSelected) FontWeight.SemiBold else FontWeight.Normal,
                            color = catTextColor
                        )

                        if (count > 0) {
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(if (isCatSelected) catInfo.primaryColor else BorderLight)
                                    .padding(horizontal = 6.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "$count",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCatSelected) PureWhite else TextSecondary
                                )
                            }
                        }
                    }
                }
            }

            // Button to Add Custom Category
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = OffWhite,
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
                modifier = Modifier
                    .clickable { showAddCategoryDialog = true }
                    .testTag("add_category_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "เพิ่มหมวดหมู่",
                        tint = SkyPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "เพิ่มหมวด",
                        fontSize = 12.sp,
                        color = SkyPrimary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }

    if (showAddCategoryDialog) {
        AlertDialog(
            onDismissRequest = {
                showAddCategoryDialog = false
                newCategoryText = ""
            },
            title = {
                Text(
                    text = "เพิ่มหมวดหมู่ใหม่",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = TextPrimary
                )
            },
            text = {
                Column {
                    Text(
                        text = "พิมพ์ชื่อหมวดหมู่ที่ต้องการ เช่น อ่านหนังสือ, การเรียน, สัตว์เลี้ยง",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = newCategoryText,
                        onValueChange = { newCategoryText = it },
                        placeholder = { Text("ชื่อหมวดหมู่...") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyPrimary,
                            unfocusedBorderColor = BorderSubtle
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newCategoryText.isNotBlank()) {
                            onAddCategory(newCategoryText.trim())
                            newCategoryText = ""
                            showAddCategoryDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SkyPrimary,
                        contentColor = PureWhite
                    )
                ) {
                    Text("เพิ่ม")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showAddCategoryDialog = false
                        newCategoryText = ""
                    }
                ) {
                    Text("ยกเลิก", color = TextSecondary)
                }
            },
            containerColor = PureWhite,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwipeableTodoItem(
    item: TodoItem,
    onToggle: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val dismissState = rememberSwipeToDismissBoxState(
        confirmValueChange = { dismissValue ->
            if (dismissValue == SwipeToDismissBoxValue.EndToStart) {
                onDelete()
                true
            } else {
                false
            }
        }
    )

    SwipeToDismissBox(
        state = dismissState,
        enableDismissFromStartToEnd = false,
        enableDismissFromEndToStart = true,
        backgroundContent = {
            val color by animateColorAsState(
                targetValue = if (dismissState.targetValue == SwipeToDismissBoxValue.EndToStart) {
                    PriorityHigh
                } else {
                    PriorityHigh.copy(alpha = 0.2f)
                },
                label = "swipe_bg_color"
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(14.dp))
                    .background(color)
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "ลบ",
                        color = PureWhite,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "ลบงาน",
                        tint = PureWhite,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        },
        content = {
            MinimalTodoItemCard(
                item = item,
                onToggle = onToggle,
                onEdit = onEdit,
                onDelete = onDelete
            )
        },
        modifier = modifier
    )
}

@Composable
fun MinimalTodoItemCard(
    item: TodoItem,
    onToggle: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val checkBorderColor by animateColorAsState(
        targetValue = if (item.isCompleted) SkyPrimary else SkyPrimaryLight.copy(alpha = 0.6f),
        label = "checkbox_border"
    )
    val checkBgColor by animateColorAsState(
        targetValue = if (item.isCompleted) SkyPrimary else PureWhite,
        label = "checkbox_fill"
    )
    val catInfo = CategoryHelper.getInfo(item.category)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, if (item.isCompleted) BorderLight else BorderSubtle, RoundedCornerShape(14.dp))
            .clickable { onEdit() }
            .testTag("todo_item_${item.id}"),
        color = if (item.isCompleted) OffWhite.copy(alpha = 0.7f) else PureWhite,
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Minimal Circle Checkbox
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(checkBgColor)
                    .border(1.5.dp, checkBorderColor, CircleShape)
                    .clickable { onToggle() }
                    .testTag("checkbox_${item.id}"),
                contentAlignment = Alignment.Center
            ) {
                if (item.isCompleted) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "เสร็จแล้ว",
                        tint = PureWhite,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Task Info
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp)
            ) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = if (item.isCompleted) FontWeight.Normal else FontWeight.Medium,
                        textDecoration = if (item.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                    ),
                    color = if (item.isCompleted) TextMuted else TextPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                if (item.note.isNotBlank()) {
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = item.note,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (item.isCompleted) TextDisabled else TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Badges row: Category Badge with Icon & Color, Priority, Reminder
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Category Badge with Distinct Color & Icon
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (item.isCompleted) catInfo.containerColor.copy(alpha = 0.4f) else catInfo.containerColor)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Icon(
                            imageVector = catInfo.icon,
                            contentDescription = null,
                            tint = if (item.isCompleted) TextMuted else catInfo.primaryColor,
                            modifier = Modifier.size(11.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = item.category,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (item.isCompleted) TextMuted else catInfo.primaryColor
                        )
                    }

                    // Priority indicator if urgent
                    if (item.priority == "สำคัญมาก" && !item.isCompleted) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(PriorityHigh.copy(alpha = 0.1f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(PriorityHigh, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "สำคัญ",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = PriorityHigh
                            )
                        }
                    }

                    // Reminder Badge
                    if (item.dueDate != null) {
                        val isPast = item.dueDate <= System.currentTimeMillis()
                        val badgeBg = if (item.isCompleted) SkyContainer.copy(alpha = 0.4f)
                        else if (isPast) PriorityHigh.copy(alpha = 0.12f)
                        else SkyPrimary.copy(alpha = 0.1f)
                        val badgeColor = if (item.isCompleted) TextMuted
                        else if (isPast) PriorityHigh
                        else SkyPrimary

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(badgeBg)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Notifications,
                                contentDescription = "เวลาแจ้งเตือน",
                                tint = badgeColor,
                                modifier = Modifier.size(11.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = formatReminderBadge(item.dueDate),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = badgeColor
                            )
                        }
                    }
                }
            }

            // Quick Delete Button
            IconButton(
                onClick = onDelete,
                modifier = Modifier
                    .size(32.dp)
                    .testTag("delete_button_${item.id}")
            ) {
                Icon(
                    imageVector = Icons.Outlined.DeleteOutline,
                    contentDescription = "ลบงานนี้",
                    tint = TextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun MinimalEmptyState(
    currentFilter: TodoFilter,
    selectedCategory: String = "ทั้งหมด"
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 48.dp, horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        val catInfo = CategoryHelper.getInfo(selectedCategory)

        Box(
            modifier = Modifier
                .size(72.dp)
                .background(catInfo.containerColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (selectedCategory != "ทั้งหมด") catInfo.icon else Icons.Outlined.CheckCircle,
                contentDescription = null,
                tint = catInfo.primaryColor,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        val title = if (selectedCategory != "ทั้งหมด") {
            "ยังไม่มีงานในหมวด \"$selectedCategory\""
        } else {
            when (currentFilter) {
                TodoFilter.ALL -> "ยังไม่มีสิ่งที่ต้องทำ"
                TodoFilter.ACTIVE -> "ไม่มีงานค้างอยู่เลย 🎉"
                TodoFilter.COMPLETED -> "ยังไม่มีงานที่เสร็จสิ้น"
            }
        }

        val subtitle = if (selectedCategory != "ทั้งหมด") {
            "แตะปุ่มด้านล่างเพื่อเพิ่มงานแรกในหมวดหมู่นี้"
        } else {
            when (currentFilter) {
                TodoFilter.ALL -> "แตะปุ่มด้านล่างเพื่อเพิ่มงานแรกของคุณ"
                TodoFilter.ACTIVE -> "คุณจัดการทุกอย่างเสร็จหมดแล้ว สบายใจได้!"
                TodoFilter.COMPLETED -> "เมื่อคุณทำเครื่องหมายเสร็จ รายการจะแสดงที่นี่"
            }
        }

        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
            color = TextPrimary
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
    }
}

@Composable
fun MinimalQuickAddBar(
    selectedCategory: String = "ทั้งหมด",
    onQuickAdd: (String) -> Unit,
    onOpenFullAdd: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    val effectiveCat = if (selectedCategory != "ทั้งหมด") selectedCategory else "ทั่วไป"
    val catInfo = CategoryHelper.getInfo(effectiveCat)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(16.dp),
        color = PureWhite,
        shadowElevation = 3.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    keyboardController?.hide()
                    focusManager.clearFocus()
                    onOpenFullAdd()
                },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.FilterList,
                    contentDescription = "ตัวเลือกเพิ่มเติม",
                    tint = SkyPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Quick Category Tag indicator
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(catInfo.containerColor)
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Icon(
                        imageVector = catInfo.icon,
                        contentDescription = null,
                        tint = catInfo.primaryColor,
                        modifier = Modifier.size(11.dp)
                    )
                    Text(
                        text = effectiveCat,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = catInfo.primaryColor
                    )
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = {
                    Text(
                        text = "พิมพ์สิ่งที่ต้องทำ...",
                        color = TextMuted,
                        fontSize = 14.sp
                    )
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    if (text.isNotBlank()) {
                        val currentText = text
                        text = ""
                        keyboardController?.hide()
                        focusManager.clearFocus()
                        onQuickAdd(currentText)
                    }
                }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("quick_add_input")
            )

            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(if (text.isNotBlank()) SkyPrimary else BorderLight)
                    .clickable(enabled = text.isNotBlank()) {
                        if (text.isNotBlank()) {
                            val currentText = text
                            text = ""
                            keyboardController?.hide()
                            focusManager.clearFocus()
                            onQuickAdd(currentText)
                        }
                    }
                    .testTag("quick_add_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "เพิ่มงาน",
                    tint = if (text.isNotBlank()) PureWhite else TextMuted,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MinimalAddEditSheet(
    initialItem: TodoItem? = null,
    categories: List<String>,
    defaultCategory: String = "ทั่วไป",
    onDismiss: () -> Unit,
    onSave: (title: String, note: String, category: String, priority: String, dueDate: Long?) -> Unit
) {
    var title by remember { mutableStateOf(initialItem?.title ?: "") }
    var note by remember { mutableStateOf(initialItem?.note ?: "") }
    var selectedCategory by remember {
        mutableStateOf(
            initialItem?.category ?: if (defaultCategory != "ทั้งหมด") defaultCategory else "ทั่วไป"
        )
    }
    var selectedPriority by remember { mutableStateOf(initialItem?.priority ?: "ปกติ") }
    var selectedDueDate by remember { mutableStateOf<Long?>(initialItem?.dueDate) }

    val priorities = listOf("สำคัญมาก", "ปกติ", "สบายๆ")
    val usableCategories = categories.filter { it != "ทั้งหมด" }

    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val safeDismiss = {
        keyboardController?.hide()
        focusManager.clearFocus()
        onDismiss()
    }

    ModalBottomSheet(
        onDismissRequest = safeDismiss,
        sheetState = sheetState,
        containerColor = PureWhite,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 12.dp)
                    .size(width = 36.dp, height = 4.dp)
                    .background(BorderSubtle, RoundedCornerShape(2.dp))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 24.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (initialItem != null) "แก้ไขสิ่งที่ต้องทำ" else "เพิ่มสิ่งที่ต้องทำใหม่",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = TextPrimary
                )
                IconButton(onClick = safeDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "ปิด",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("ชื่องาน / กิจกรรม") },
                placeholder = { Text("เช่น ซื้อของสด, ส่งงานโปรเจกต์") },
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SkyPrimary,
                    unfocusedBorderColor = BorderSubtle,
                    focusedLabelColor = SkyPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dialog_title_input")
            )

            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("รายละเอียดเพิ่มเติม (ไม่บังคับ)") },
                placeholder = { Text("โน้ตย่อหรือคำอธิบาย...") },
                maxLines = 3,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SkyPrimary,
                    unfocusedBorderColor = BorderSubtle,
                    focusedLabelColor = SkyPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dialog_note_input")
            )

            // Category selection with Icon and Colors
            Column {
                Text(
                    text = "หมวดหมู่ (Category)",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    usableCategories.forEach { cat ->
                        val isSelected = selectedCategory == cat
                        val catInfo = CategoryHelper.getInfo(cat)

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) catInfo.containerColor else OffWhite,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) catInfo.primaryColor else BorderSubtle
                            ),
                            modifier = Modifier.clickable { selectedCategory = cat }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    imageVector = catInfo.icon,
                                    contentDescription = null,
                                    tint = if (isSelected) catInfo.primaryColor else TextSecondary,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = cat,
                                    fontSize = 12.sp,
                                    color = if (isSelected) catInfo.primaryColor else TextSecondary,
                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            }

            // Priority selection
            Column {
                Text(
                    text = "ความสำคัญ (Priority)",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    priorities.forEach { prio ->
                        val isSelected = selectedPriority == prio
                        val pColor = when (prio) {
                            "สำคัญมาก" -> PriorityHigh
                            "ปกติ" -> SkyPrimary
                            else -> TextSecondary
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) pColor.copy(alpha = 0.12f) else OffWhite)
                                .border(
                                    1.dp,
                                    if (isSelected) pColor else BorderSubtle,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedPriority = prio }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = prio,
                                fontSize = 12.sp,
                                color = if (isSelected) pColor else TextSecondary,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            // Reminder Notification Selection
            Column {
                Text(
                    text = "⏰ แจ้งเตือนความจำ (Notification)",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))

                if (selectedDueDate != null) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = SkyContainer,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SkyPrimaryLight)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Outlined.NotificationsActive,
                                    contentDescription = null,
                                    tint = SkyPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "เตือน: ${formatReminderBadge(selectedDueDate!!)}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = OnSkyContainer
                                )
                            }
                            IconButton(
                                onClick = { selectedDueDate = null },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "ยกเลิกการเตือน",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val presets = listOf(
                        "ไม่เตือน" to null,
                        "+15 นาที" to (15 * 60 * 1000L),
                        "+1 ชม." to (60 * 60 * 1000L),
                        "+3 ชม." to (3 * 60 * 60 * 1000L),
                        "พรุ่งนี้ 09:00" to -1L
                    )

                    presets.forEach { (label, offset) ->
                        val isNone = offset == null && selectedDueDate == null

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isNone) SkyContainer else OffWhite)
                                .border(
                                    1.dp,
                                    if (isNone) SkyPrimaryLight else BorderSubtle,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    if (offset == null) {
                                        selectedDueDate = null
                                    } else if (offset == -1L) {
                                        // Tomorrow 9:00 AM
                                        val cal = Calendar.getInstance().apply {
                                            add(Calendar.DAY_OF_YEAR, 1)
                                            set(Calendar.HOUR_OF_DAY, 9)
                                            set(Calendar.MINUTE, 0)
                                            set(Calendar.SECOND, 0)
                                            set(Calendar.MILLISECOND, 0)
                                        }
                                        selectedDueDate = cal.timeInMillis
                                    } else {
                                        selectedDueDate = System.currentTimeMillis() + offset
                                    }
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = label,
                                fontSize = 12.sp,
                                color = if (isNone) OnSkyContainer else TextSecondary,
                                fontWeight = if (isNone) FontWeight.SemiBold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Action Buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TextButton(
                    onClick = safeDismiss,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("ยกเลิก", color = TextSecondary)
                }

                Button(
                    onClick = {
                        if (title.isNotBlank()) {
                            keyboardController?.hide()
                            focusManager.clearFocus()
                            onSave(title, note, selectedCategory, selectedPriority, selectedDueDate)
                        }
                    },
                    enabled = title.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SkyPrimary,
                        contentColor = PureWhite
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1.5f)
                        .testTag("dialog_save_button")
                ) {
                    Text(if (initialItem != null) "บันทึกการแก้ไข" else "สร้างงาน")
                }
            }
        }
    }
}
